/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\alex_                                            */
/*    Created:      Mon Aug 14 2023                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// FrontLeft            motor         7               
// FrontRight           motor         11              
// BackLeft             motor         17              
// BackRight            motor         5               
// Controller1          controller                    
// Flap1                digital_out   A               
// Flap2                digital_out   B               
// ---- END VEXCODE CONFIGURED DEVICES ----


#include "vex.h"
#include <string.h>
#include <iostream>
#include <sstream>
#include <vector>

using namespace std;
using namespace vex;
int go;
int rotate;
bool intaking;
int count;
std::string save = "";
template <typename T>

std::string ToString(T val)
{
    std::stringstream stream;
    stream << val;
    return stream.str();
}

competition Competition;

void pre_auton(void) {
  vexcodeInit();
  Intake.setMaxTorque(9000, percent);
}

void autonomous(void) {

}

void usercontrol(void) {
  std::cout << "START" << "\n";
  while (1) {  
    //get inputs
    go = Controller1.Axis3.position(percent);
    rotate = Controller1.Axis1.position(percent);
    //modify and record inputs
    go = (int)(go + 99) / 2;
    rotate = (int)(rotate + 99) / 2;
    if(go < 10){
      save = save + "0";
      save = save + ToString(go);
    }
    else{
      save = save + ToString(go);
    }
    if(rotate < 10){
      save = save + "0";
      save = save + ToString(rotate);
    }
    else{
      save = save + ToString(rotate);
    }
    //spin the chassis
    if(go != 49 || rotate != 49){
      if(rotate == 49){
        FrontLeft.spin(vex::forward, go * 2 - 99, percent);
        FrontRight.spin(vex::forward, go * 2 - 99, percent);
        BackLeft.spin(vex::forward, go * 2 - 99, percent);
        BackRight.spin(vex::forward, go * 2 - 99, percent);
      }
      else{
        FrontLeft.spin(vex::forward, (go * 2 - 99) + (rotate * 2 - 99), percent);
        FrontRight.spin(vex::forward, (go * 2 - 99) - (rotate * 2 - 99), percent);
        BackLeft.spin(vex::forward, (go * 2 - 99) + (rotate * 2 - 99), percent);
        BackRight.spin(vex::forward, (go * 2 - 99) - (rotate * 2 - 99), percent);
      }
    }
    else{
      FrontLeft.stop();
      FrontRight.stop();
      BackLeft.stop();
      BackRight.stop();
    }
    if(Controller1.ButtonL2.pressing())
    {
      Flap1.set(true);
    }
    else
    {
      Flap1.set(false);
    }
    if(Controller1.ButtonR2.pressing())
    {
      Flap2.set(true);
    }
    else
    {
      Flap2.set(false);
    }
    if(save.length() > 400){
      std::cout << save << "\n";
      save = "";
    }
    wait(20, msec);
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {

    wait(100, msec);
  }
}

